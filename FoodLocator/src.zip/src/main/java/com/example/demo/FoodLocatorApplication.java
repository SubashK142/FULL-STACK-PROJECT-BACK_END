package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FoodLocatorApplication {

	public static void main(String[] args) {
		SpringApplication.run(FoodLocatorApplication.class, args);
	}

}
